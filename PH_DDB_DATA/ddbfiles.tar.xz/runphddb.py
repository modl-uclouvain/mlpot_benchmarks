
import subprocess
import os
import logging

def run_abiml_phddb_for_mpids(base_dir="/home/ucl/modl/hayu/git_repos"):
    ddb_dir = os.path.join(base_dir, "phonondiagram/ddb")
    logging.basicConfig(filename='abiml_phddb_errors.log', level=logging.ERROR)

    for filename in os.listdir(ddb_dir):
        if filename.startswith("mp-"):
            mp_id = filename
            output_dir = os.path.join(base_dir, f"_abiml_phddb_{mp_id}")
            ddb_file_path = os.path.join(ddb_dir, filename)
            command = f"{base_dir}/abipy/abipy/scripts/abiml.py phddb {ddb_file_path} --nn-names all --fmax 0.1  --supercell 6 6 6 -w {output_dir}"

            try:
                subprocess.run(command, shell=True, check=True)
            except subprocess.CalledProcessError as e:
                logging.error(f"Error executing command for {mp_id}: {e}")
                logging.error(f"Command: {command}")

run_abiml_phddb_for_mpids()

